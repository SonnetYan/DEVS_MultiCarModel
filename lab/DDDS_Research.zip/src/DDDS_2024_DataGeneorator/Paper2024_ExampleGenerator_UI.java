package DDDS_2024_DataGeneorator;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.EventQueue;

public class Paper2024_ExampleGenerator_UI {
    private JFrame frame;
    private JTextField runField;
    private JTextField carPassingTimeMeanField; // New field

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Paper2024_ExampleGenerator_UI window = new Paper2024_ExampleGenerator_UI();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Paper2024_ExampleGenerator_UI() {
        initialize();
    }

    private void initialize() {
        // Frame setup
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
    
        // Run label and field
        JLabel lblRun = new JLabel("Run:");
        lblRun.setBounds(10, 11, 46, 14);
        frame.getContentPane().add(lblRun);
    
        runField = new JTextField();
        runField.setBounds(66, 11, 86, 20);
        frame.getContentPane().add(runField);
        runField.setColumns(10);
        runField.setText(String.valueOf(model_configData.total_run));
    
        // Car Passing Time Mean label and field
        JLabel lblCarPassingTimeMean = new JLabel("Car Passing Time Mean:");
        lblCarPassingTimeMean.setBounds(10, 41, 150, 14);
        frame.getContentPane().add(lblCarPassingTimeMean);
    
        carPassingTimeMeanField = new JTextField();
        carPassingTimeMeanField.setBounds(170, 41, 86, 20);
        frame.getContentPane().add(carPassingTimeMeanField);
        carPassingTimeMeanField.setColumns(10);
        carPassingTimeMeanField.setText(String.valueOf(model_configData.carPassingTime_mean));
    
        // East Moving Lambda label and field
        JLabel lblEastMovingLambda = new JLabel("East arriving Rate: 1/");
        lblEastMovingLambda.setBounds(10, 71, 150, 14);
        frame.getContentPane().add(lblEastMovingLambda);
        
        JTextField eastMovingLambdaField = new JTextField();
        eastMovingLambdaField.setBounds(170, 71, 86, 20);
        eastMovingLambdaField.setColumns(10);
        eastMovingLambdaField.setText(String.valueOf(1/model_configData.generator_eastMoving_lambda));
        frame.getContentPane().add(eastMovingLambdaField);
    
        // West Moving Lambda label and field
        JLabel lblWestMovingLambda = new JLabel("West Arriving Rate 1/" );
        lblWestMovingLambda.setBounds(10, 101, 150, 14);
        frame.getContentPane().add(lblWestMovingLambda);
        
        JTextField westMovingLambdaField = new JTextField();
        westMovingLambdaField.setBounds(170, 101, 86, 20);
        westMovingLambdaField.setColumns(10);
        westMovingLambdaField.setText(String.valueOf(1/model_configData.generator_westMoving_lambda));
        frame.getContentPane().add(westMovingLambdaField);
    
        // Max Elapse Time When Busy for East to West label and field
        JLabel lblMaxElapseTimeWhenBusyE2W = new JLabel("maxLightSwitchTime E2W:");
        lblMaxElapseTimeWhenBusyE2W.setBounds(10, 131, 150, 14);
        frame.getContentPane().add(lblMaxElapseTimeWhenBusyE2W);
        
        JTextField maxElapseTimeWhenBusyFieldE2W = new JTextField();
        maxElapseTimeWhenBusyFieldE2W.setBounds(170, 131, 86, 20);
        maxElapseTimeWhenBusyFieldE2W.setColumns(10);
        maxElapseTimeWhenBusyFieldE2W.setText(String.valueOf(model_configData.maxElapseTimeWhenBusy_E2W));
        frame.getContentPane().add(maxElapseTimeWhenBusyFieldE2W);

        // Max Elapse Time When Busy for West to East label and field
        JLabel lblMaxElapseTimeWhenBusyW2E = new JLabel("maxLightSwitchTime W2E:");
        lblMaxElapseTimeWhenBusyW2E.setBounds(10, 161, 150, 14);
        frame.getContentPane().add(lblMaxElapseTimeWhenBusyW2E);
        
        JTextField maxElapseTimeWhenBusyFieldW2E = new JTextField();
        maxElapseTimeWhenBusyFieldW2E.setBounds(170, 161, 86, 20);
        maxElapseTimeWhenBusyFieldW2E.setColumns(10);
        maxElapseTimeWhenBusyFieldW2E.setText(String.valueOf(model_configData.maxElapseTimeWhenBusy_W2E));
        frame.getContentPane().add(maxElapseTimeWhenBusyFieldW2E);
        
        // Start button
        JButton btnStart = new JButton("Start Simulation");
        btnStart.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                int run = Integer.parseInt(runField.getText());
                double carPassingTimeMean = Double.parseDouble(carPassingTimeMeanField.getText());
                model_configData.carPassingTime_mean = carPassingTimeMean;
                double eastMovingLambda = Double.parseDouble(eastMovingLambdaField.getText());
                model_configData.generator_eastMoving_lambda = 1/eastMovingLambda;
                double westMovingLambda = Double.parseDouble(westMovingLambdaField.getText());
                model_configData.generator_westMoving_lambda = 1/ westMovingLambda;

                double maxElapseTimeWhenBusyE2W = Double.parseDouble(maxElapseTimeWhenBusyFieldE2W.getText());
                model_configData.maxElapseTimeWhenBusy_E2W = maxElapseTimeWhenBusyE2W;
                double maxElapseTimeWhenBusyW2E = Double.parseDouble(maxElapseTimeWhenBusyFieldW2E.getText());
                model_configData.maxElapseTimeWhenBusy_W2E = maxElapseTimeWhenBusyW2E;
                String[] args = {String.valueOf(run)};
                test.main(args);

                String a ="{\n" +
                        "  \"info_type\": \"simulation\",\n" +
                        "  \"team_num\": 2,\n" +
                        "  \"total_sim_time\": 12000,\n" +
                        "  \"team_infos\": [\n" +
                        "    {\n" +
                        "      \"team_name\": \"team0\",\n" +
                        "      \"info_num\": 3,\n" +
                        "      \"details\": [\n" +
                        "        {\n" +
                        "          \"type\": \"segment\",\n" +
                        "          \"start_x\": 78,\n" +
                        "          \"start_y\": 146,\n" +
                        "          \"end_x\": 56,\n" +
                        "          \"end_y\": 146,\n" +
                        "          \"speed\": 0.6,\n" +
                        "          \"mode\": \"continuous\",\n" +
                        "          \"distance\": null\n" +
                        "        },\n" +
                        "        {\n" +
                        "          \"type\": \"segment\",\n" +
                        "          \"start_x\": 56,\n" +
                        "          \"start_y\": 146,\n" +
                        "          \"end_x\": 59,\n" +
                        "          \"end_y\": 87,\n" +
                        "          \"speed\": 0.6,\n" +
                        "          \"mode\": \"continuous\",\n" +
                        "          \"distance\": null\n" +
                        "        },\n" +
                        "        {\n" +
                        "          \"type\": \"segment\",\n" +
                        "          \"start_x\": 59,\n" +
                        "          \"start_y\": 87,\n" +
                        "          \"end_x\": 126,\n" +
                        "          \"end_y\": 87,\n" +
                        "          \"speed\": 0.6,\n" +
                        "          \"mode\": \"continuous\",\n" +
                        "          \"distance\": null\n" +
                        "        }\n" +
                        "      ]\n" +
                        "    },\n" +
                        "    {\n" +
                        "      \"team_name\": \"team1\",\n" +
                        "      \"info_num\": 3,\n" +
                        "      \"details\": [\n" +
                        "        {\n" +
                        "          \"type\": \"segment\",\n" +
                        "          \"start_x\": 83,\n" +
                        "          \"start_y\": 147,\n" +
                        "          \"end_x\": 150,\n" +
                        "          \"end_y\": 147,\n" +
                        "          \"speed\": 0.6,\n" +
                        "          \"mode\": \"continuous\",\n" +
                        "          \"distance\": null\n" +
                        "        },\n" +
                        "        {\n" +
                        "          \"type\": \"segment\",\n" +
                        "          \"start_x\": 150,\n" +
                        "          \"start_y\": 147,\n" +
                        "          \"end_x\": 152,\n" +
                        "          \"end_y\": 88,\n" +
                        "          \"speed\": 0.6,\n" +
                        "          \"mode\": \"continuous\",\n" +
                        "          \"distance\": null\n" +
                        "        },\n" +
                        "        {\n" +
                        "          \"type\": \"segment\",\n" +
                        "          \"start_x\": 152,\n" +
                        "          \"start_y\": 88,\n" +
                        "          \"end_x\": 129,\n" +
                        "          \"end_y\": 88,\n" +
                        "          \"speed\": 0.6,\n" +
                        "          \"mode\": \"continuous\",\n" +
                        "          \"distance\": null\n" +
                        "        }\n" +
                        "      ]\n" +
                        "    }\n" +
                        "  ],\n" +
                        "  \"windSpeed\": 10,\n" +
                        "  \"windDegree\": 180,\n" +
                        "  \"sup_infos\": [\n" +
                        "    {\n" +
                        "      \"type\": \"supLine\",\n" +
                        "      \"start_x\": 55,\n" +
                        "      \"start_y\": 133,\n" +
                        "      \"end_x\": 56,\n" +
                        "      \"end_y\": 86\n" +
                        "    },\n" +
                        "    {\n" +
                        "      \"type\": \"supLine\",\n" +
                        "      \"start_x\": 56,\n" +
                        "      \"start_y\": 86,\n" +
                        "      \"end_x\": 155,\n" +
                        "      \"end_y\": 86\n" +
                        "    },\n" +
                        "    {\n" +
                        "      \"type\": \"supLine\",\n" +
                        "      \"start_x\": 155,\n" +
                        "      \"start_y\": 86,\n" +
                        "      \"end_x\": 151,\n" +
                        "      \"end_y\": 149\n" +
                        "    },\n" +
                        "    {\n" +
                        "      \"type\": \"supLine\",\n" +
                        "      \"start_x\": 151,\n" +
                        "      \"start_y\": 149,\n" +
                        "      \"end_x\": 54,\n" +
                        "      \"end_y\": 148\n" +
                        "    },\n" +
                        "    {\n" +
                        "      \"type\": \"supLine\",\n" +
                        "      \"start_x\": 54,\n" +
                        "      \"start_y\": 148,\n" +
                        "      \"end_x\": 56,\n" +
                        "      \"end_y\": 132\n" +
                        "    }\n" +
                        "  ],\n" +
                        "  \"proj_center_lng\": -35619.01701560877,\n" +
                        "  \"proj_center_lat\": 1526271.822562622,\n" +
                        "  \"sup_num\": 5\n" +
                        "}\n";
            }
        });
        btnStart.setBounds(162, 190, 150, 23);
        frame.getContentPane().add(btnStart);
    }
}