package GenCol;



public interface EntityInterface{    //for some reason Entity doesn't generate .class file
public String getName();
public Object equalName(String name);
public ExternalRepresentation getExtRep();
}





