package GenCol;



public interface ExternalRepresentation{


class ByteArray implements ExternalRepresentation{}



}