package GenCol;

import java.util.*;

interface ensembleLogic {
public boolean none(String MethodNm,Class[] classes,Object[] args);
public boolean all(String MethodNm,Class[] classes,Object[] args);
}

