package GenCol;


import java.util.*;




public interface ensembleInterface extends ensembleBasic,ensembleCollection,ensembleLogic{}