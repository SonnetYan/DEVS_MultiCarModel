package DDDS_Paper_Various_PF_DA_carPassingTime_SeriesBatch;

public class PF_configData {

	public static int numberofsteps = 201;//80; 
	public static double stepInterval = 30; //60;  // 18 seconds

	public static int numberofparticles = 4000;//6000;//1000;
	
	public static int currentStepIndex = 0;///
	public static int currentParticleIndex = 0;
	public static double currTime = 0;

	public static double real_carPassingTime = 3.0;
	public static String realName = "Real_";
	public static String DataPathName = "DATA2/observeData/";//"chapter6Tutorial2/";
	public static String stepResultPathName = "DATA2/stepResult_DA/";//"chapter6Tutorial2/";
	public static String observedDataPathName = "DATA2/observeData/";
	public static String realSensorDataFileName = "observationData.txt";
	public static String resultDataFileName= "DATA2/Result_DA/";
	
	public static long PF_globalRandSeed = 88788;//444;//
	
	public static long RTPrediction_randSeed = 66666;
	
}






