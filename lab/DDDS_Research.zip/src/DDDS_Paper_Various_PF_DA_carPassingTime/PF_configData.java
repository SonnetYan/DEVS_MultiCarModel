package DDDS_Paper_Various_PF_DA_carPassingTime;

public class PF_configData {

	public static int numberofsteps = 360;//80; 
	public static double stepInterval = 30; //60;  // 18 seconds

	public static int numberofparticles = 4000;//6000;//1000;
	
	public static int currentStepIndex = 0;///
	public static int currentParticleIndex = 0;
	public static double currTime = 0;

	
	public static String realName = "Real_5.0/";
	public static String DataPathName = "DATA/"+realName+"/observeData/";//"chapter6Tutorial2/";
	public static String stepResultPathName = "DATA/"+realName+"/stepResult_DA/";//"chapter6Tutorial2/";
	public static String realSensorDataFileName = "observationData.txt";
	public static String resultDataFileName= "DATA/"+realName+"/DA_Result/";
	
	public static long PF_globalRandSeed = 88788;//444;//
	
	public static long RTPrediction_randSeed = 66666;
	
}






