package genDevs.simulation;
import GenCol.*;

import java.util.*;

public interface CoupledCoordinatorInterface
             extends CoordinatorInterface
                      ,CouplingProtocolInterface
                      ,HierParent
                      { }


