package genDevs.modeling;

import GenCol.*;

import java.util.*;


public class port extends entity implements PortInterface{
public port(String nm){
super(nm);
}
}





