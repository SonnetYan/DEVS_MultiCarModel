package genDevs.modeling;

import GenCol.*;

import java.util.*;


public interface ComponentsInterface extends ensembleInterface{
public componentIterator cIterator();
}





