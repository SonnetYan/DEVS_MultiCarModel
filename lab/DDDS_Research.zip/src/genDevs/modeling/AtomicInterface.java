package genDevs.modeling;

import GenCol.*;
import java.util.*;

interface AtomicInterface extends atomicDevs,IOBasicDevs{}

