package genDevs.modeling;

public interface Coupled extends coupledDevs,IOBasicDevs{

}
