
package genDevs.modeling;

import GenCol.*;

import java.util.*;




public interface ContentIteratorInterface{
public boolean hasNext();
public ContentInterface next();
}