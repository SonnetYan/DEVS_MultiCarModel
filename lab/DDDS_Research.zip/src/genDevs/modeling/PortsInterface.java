package genDevs.modeling;

import GenCol.*;
import java.util.*;

interface PortsInterface extends Collection{
}
