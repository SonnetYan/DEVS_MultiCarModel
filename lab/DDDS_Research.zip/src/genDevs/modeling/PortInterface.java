package genDevs.modeling;

import GenCol.*;

import java.util.*;


public interface PortInterface extends EntityInterface{}

interface portIterator extends Iterator{
public PortInterface nextPort();
}

