package DDDS_Paper_Various_DataGeneorator_SeriesBatch;

public class PF_configData {

	public static int numberofsteps = 300;//80; 
	public static double stepInterval = 30; //60;  // 18 seconds

	public static int numberofparticles = 2000;//6000;//1000;
	
	public static int currentStepIndex = 0;///
	public static int currentParticleIndex = 0;
	public static double currTime = 0;

	public static String DataPathName = "DATA2/otherData/";
	public static String observedDataPathName = "DATA2/observeData/";
	public static String realSensorDataFileName = "observationData.txt";
	
	public static long PF_globalRandSeed = 673267;//444;//
	
	public static long RTPrediction_randSeed = 66666;
	
}







