package DDDS_Paper_Various_Daynamic_DataGeneorator;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Random;

import GenCol.*;
import genDevs.modeling.*;
import genDevs.simulation.*;
import genDevs.simulation.realTime.*;


public class test{

protected static digraph testDig;

  public test(){}
  

  public static void main(String[ ] args)
  {
	  PrintWriter Real_TotalInfo = null;

	  
      long seed = 42;  
      Random rand = new Random(seed);
	  
	  for(int run = 0; run < 20; run++) {
		  
		  model_configData.randSeed_eastMoving = rand.nextInt();
		  model_configData.randSeed_westMoving = rand.nextInt();
		  model_configData.randSeed_IntersectionM = rand.nextInt();
		
	      testDig = new trafficControlSys_Real();
	      genDevs.simulation.coordinator cs = new genDevs.simulation.coordinator(testDig);
	      cs.initialize();
	      cs.simulate_TN(PF_configData.numberofsteps*PF_configData.stepInterval+2000); 
	      System.out.println("simulation finsihed");
	      model_configData.run++;
	  }
  }
}
