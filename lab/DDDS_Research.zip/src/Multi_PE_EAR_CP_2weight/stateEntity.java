package Multi_PE_EAR_CP_2weight;

import GenCol.*;
import genDevs.modeling.DevsInterface;

public class stateEntity extends entity{

protected String TrafficLightState; 
  protected double sigma;
  protected double elapseTimeInGreen;
  protected int westSideQueue, eastSideQueue;
  protected double eastArrivingRate,westArrivingRate;
  
  //For parameter estimation 
  protected double carPassingTime;
  
  
  public stateEntity(){
	  this(0, 0, "eastMovingGreen_passive", DevsInterface.INFINITY, 0, model_configData.carPassingTime_mean,model_configData.generator_eastMoving_lambda,model_configData.generator_westMoving_lambda);
  }
  
  public stateEntity(int Wq, int Eq, String GreenLtSt, double sgm, double elapseTimeGreen, double carPTime,double eAR, double wAR){
	  super("stateEntity");
	  westSideQueue = Wq;
	  eastSideQueue = Eq;
	  TrafficLightState = GreenLtSt;
	  sigma = sgm;
	  elapseTimeInGreen = elapseTimeGreen;
	  carPassingTime= carPTime;
	  westArrivingRate = wAR;
	  eastArrivingRate = eAR;
	  
  }
  
  public String toString(){
	  //return name+"_"+processingTime;
	  return westSideQueue+"_"+eastSideQueue+"_"+TrafficLightState
			  +"_"+sigma+"_"+elapseTimeInGreen+"_"+carPassingTime;
//			  ((double)((int)(elapseTimeInGreen*1000)))/1000;
  }
		
}
