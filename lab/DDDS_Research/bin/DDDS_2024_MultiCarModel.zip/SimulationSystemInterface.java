package DDDS_2024_MultiCarModel;

public interface SimulationSystemInterface {
    public double getSimulationTime() ;
}
